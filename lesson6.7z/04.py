#4

class Car:
    def __init__(self, speed, color, name, is_police):
        self.speed = speed
        self.color = color
        self.name = name
        self.is_police = is_police

    def go(self):
        print('Start going')

    def stop(self):
        print('Stop')

    def turn_direction(self, direction):
        print('Turn to: ', direction)

    def show_speed(self):
        print('Speed', self.speed)

class SportCar(Car):
    pass

class TownCar(Car):
    def show_speed(self):
        super().show_speed()
        if self.speed > 60:
            print('Speed is more than max')



class WorkCar(Car):
    def show_speed(self):
        super().show_speed()
        if self.speed > 40:
            print('Speed is more than max')

class PoliceCar(Car):
    def __init__(self, speed, color, name, is_police):
        super().__init__(speed, color, name, is_police = True)



sport_car = SportCar(100, 'green', 'sport', False)
town_car = TownCar(100, 'red', 'town', False)
work_car = WorkCar(100, 'blue', 'work', False)
police_car = PoliceCar(100, 'grey', 'police', True)


sport_car.go()
sport_car.show_speed()
sport_car.turn_direction('left')
sport_car.stop()