#2

class road():

    def __init__(self, length, width):
        self._length = length
        self._width = width

    def cover(self):
        mass = self._length * self._width * 25 * 5
        return mass

print (road(100, 20).cover())