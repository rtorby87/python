#1
from time import sleep

class TrafficLight:
    def __init__(self):
        self._color = ['Red', 'Yellow', 'Green']


    def running(self):
        i = 0
        while i < 4:
            for color in self._color:
                if color in 'Red':
                    print('Red')
                elif color in 'Yellow':
                    sleep(7)
                    print('Yellow')
                    sleep(2)
                else:
                    print('Green')
                sleep(2)
            i = i + 1

traffic_light = TrafficLight()
traffic_light.running()