 3

class worker():

    def __init__(self, name, surname, position, income):
        self._name = name
        self._surname = surname
        self._position = position
        self._income_wage = income['wage']
        self._income_bonus = income['bonus']

class position(worker):

    def get_full_name(self):
        return f'{self._name} {self._surname} {self._position}'

    def get_total_income(self):
        total_income = self._income_wage + self._income_bonus
        return total_income

p = position('Kirill', 'Kirillov', 'intern', {'wage': 10000, 'bonus': 1000})
print(p.get_full_name())
print(p.get_total_income())